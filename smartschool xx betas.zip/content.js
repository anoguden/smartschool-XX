/**
 * content.js — Smartschool Thema-Aanpasser
 * Injecteer CSS in de Smartschool-pagina op basis van de opgeslagen instellingen.
 *
 * Structuur:
 *  1. Constanten & stijl-injectie helpers
 *  2. Thema-definities
 *  3. Bouw CSS op basis van instellingen
 *  4. Initialisatie bij pagina-load
 *  5. Luister naar berichten vanuit popup.js
 *  6. TODO: GAMES-SECTIE
 */

'use strict';

// ── 1. Helpers voor stijl-injectie ───────────────────────────────────────────

const STYLE_ID = 'smsc-thema-aanpasser';

/**
 * Schrijft (of overschrijft) een <style>-tag met de gegeven CSS.
 * @param {string} css
 */
function injectCSS(css) {
  let styleEl = document.getElementById(STYLE_ID);
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = STYLE_ID;
    document.head.appendChild(styleEl);
  }
  styleEl.textContent = css;
}

/** Verwijdert alle geïnjecteerde stijlen. */
function removeCSS() {
  const el = document.getElementById(STYLE_ID);
  if (el) el.remove();
}

// ── 2. Thema-definities ───────────────────────────────────────────────────────
//
// Selectors die hier gebruikt worden (pas aan als Smartschool ze wijzigt):
//   #smscMain          — hoofdcontainer van de pagina
//   .smsc-appbar       — bovenste navigatiebalk
//   .smsc-sidenav      — zijbalk / navigatiemenu
//   .smsc-card         — kaartcomponenten (berichten, taken, …)
//   .smsc-btn          — knoppen
//   .smsc-topbar       — secundaire topbalk (indien aanwezig)
//
// Voeg hier extra selectors toe als je meer elementen wilt stylen.

const THEMES = {
  dark: {
    '--bg-main':       '#0f0f1a',
    '--bg-sidebar':    '#1a1a2e',
    '--bg-card':       '#1e1e32',
    '--bg-appbar':     '#16213e',
    '--text-primary':  '#e0e0f0',
    '--text-secondary':'#9090b0',
    '--accent':        '#6c63ff',
    '--accent-hover':  '#857dff',
    '--border':        'rgba(255,255,255,0.07)',
  },
  ocean: {
    '--bg-main':       '#071a2f',
    '--bg-sidebar':    '#0a2342',
    '--bg-card':       '#0d2b4e',
    '--bg-appbar':     '#0a1f3a',
    '--text-primary':  '#cce8ff',
    '--text-secondary':'#7ab3d8',
    '--accent':        '#00b4d8',
    '--accent-hover':  '#0096c7',
    '--border':        'rgba(0,180,216,0.15)',
  },
  sunset: {
    '--bg-main':       '#1a0a00',
    '--bg-sidebar':    '#2d1200',
    '--bg-card':       '#3a1800',
    '--bg-appbar':     '#2a0f00',
    '--text-primary':  '#ffe8d6',
    '--text-secondary':'#cc9070',
    '--accent':        '#ff6b35',
    '--accent-hover':  '#ff8c5a',
    '--border':        'rgba(255,107,53,0.2)',
  },
};

// ── 3. CSS genereren op basis van instellingen ────────────────────────────────

/**
 * Bouwt de CSS-string op voor een vooraf ingesteld thema.
 * @param {string} themeName - 'dark' | 'ocean' | 'sunset'
 * @returns {string} CSS
 */
function buildThemeCSS(themeName) {
  const vars = THEMES[themeName];
  if (!vars) return '';

  const cssVars = Object.entries(vars)
    .map(([k, v]) => `  ${k}: ${v};`)
    .join('\n');

  return `
/* ── Smartschool Thema: ${themeName} ── */
:root {
${cssVars}
}

/* Hoofd-wrapper */
#smscMain,
body {
  background-color: var(--bg-main) !important;
  color: var(--text-primary) !important;
}

/* Bovenste balk */
.smsc-appbar,
.smsc-topbar,
[class*="appbar"],
[class*="topbar"],
nav.navbar {
  background-color: var(--bg-appbar) !important;
  border-bottom: 1px solid var(--border) !important;
  box-shadow: 0 2px 8px rgba(0,0,0,0.4) !important;
}

/* Zijbalk */
.smsc-sidenav,
[class*="sidenav"],
[class*="sidebar"],
aside {
  background-color: var(--bg-sidebar) !important;
  border-right: 1px solid var(--border) !important;
}

/* Navigatie-links in de zijbalk */
.smsc-sidenav a,
[class*="sidenav"] a,
aside a {
  color: var(--text-secondary) !important;
  transition: color 0.2s, background 0.2s;
}
.smsc-sidenav a:hover,
[class*="sidenav"] a:hover,
aside a:hover {
  color: var(--text-primary) !important;
  background: rgba(255,255,255,0.05) !important;
}

/* Kaarten */
.smsc-card,
[class*="card"],
.panel,
.widget {
  background-color: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  color: var(--text-primary) !important;
  border-radius: 8px;
}

/* Knoppen */
.smsc-btn,
[class*="btn-primary"],
button[type="submit"] {
  background-color: var(--accent) !important;
  border-color: var(--accent) !important;
  color: #fff !important;
}
.smsc-btn:hover,
[class*="btn-primary"]:hover,
button[type="submit"]:hover {
  background-color: var(--accent-hover) !important;
}

/* Tekst aanpassingen */
h1, h2, h3, h4, h5, h6,
p, span, label, td, th {
  color: var(--text-primary) !important;
}
.text-muted, small, .helper-text {
  color: var(--text-secondary) !important;
}

/* Tabel-rijen */
tr:nth-child(even) { background: rgba(255,255,255,0.03) !important; }
tr:hover           { background: rgba(255,255,255,0.06) !important; }

/* Scrollbar */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--bg-sidebar); }
::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 3px; }
`;
}

/**
 * Bouwt de CSS-string op voor een eigen achtergrondafbeelding
 * met een optionele kleuroverlay.
 *
 * @param {string} dataUrl      - base64 afbeelding
 * @param {string|null} overlay - 'rgba(...)' of null
 * @returns {string} CSS
 */
function buildCustomBgCSS(dataUrl, overlay) {
  const overlayRule = overlay
    ? `#smscMain::before {
  content: '';
  position: fixed;
  inset: 0;
  background: ${overlay};
  pointer-events: none;
  z-index: 0;
}`
    : '';

  return `
/* ── Smartschool: eigen achtergrond ── */
body,
#smscMain {
  background-image: url("${dataUrl}") !important;
  background-size: cover !important;
  background-attachment: fixed !important;
  background-position: center !important;
}

/* Glazen kaart-effect bij eigen achtergrond */
.smsc-card,
[class*="card"],
.panel,
.widget {
  background: rgba(10, 10, 30, 0.65) !important;
  backdrop-filter: blur(10px) !important;
  -webkit-backdrop-filter: blur(10px) !important;
  border: 1px solid rgba(255,255,255,0.1) !important;
  color: #fff !important;
  border-radius: 8px;
}

.smsc-appbar,
.smsc-topbar,
[class*="appbar"],
nav.navbar {
  background: rgba(10, 10, 30, 0.75) !important;
  backdrop-filter: blur(14px) !important;
  -webkit-backdrop-filter: blur(14px) !important;
}

.smsc-sidenav,
[class*="sidenav"],
aside {
  background: rgba(10, 10, 30, 0.7) !important;
  backdrop-filter: blur(12px) !important;
  -webkit-backdrop-filter: blur(12px) !important;
}

h1, h2, h3, h4, h5, h6,
p, span, label, a, td, th { color: #fff !important; }

${overlayRule}
`;
}

// ── 4. Initialisatie bij pagina-load ─────────────────────────────────────────

chrome.storage.local.get('smscSettings', ({ smscSettings }) => {
  if (smscSettings) applySettings(smscSettings);
});

// ── 5. Luister naar berichten vanuit popup.js ─────────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'APPLY_THEME') {
    applySettings(message.settings);
  }
  // TODO: GAMES-SECTIE — voeg hier extra message-types toe
  // bijv.: if (message.type === 'OPEN_GAME') { ... }
});

/**
 * Centrale functie: past de pagina aan op basis van de instellingen.
 * @param {object} settings
 */
function applySettings(settings) {
  if (!settings) { removeCSS(); return; }

  const { theme, customBg, overlayColor } = settings;

  if (customBg) {
    injectCSS(buildCustomBgCSS(customBg, settings.useOverlay ? overlayColor : null));
  } else if (theme && THEMES[theme]) {
    injectCSS(buildThemeCSS(theme));
  } else {
    removeCSS();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TODO: GAMES-SECTIE
// Voeg hier de DOM-manipulatie toe voor eventuele in-page games of widgets.
// Voorbeeld: een zwevende knop injecteren die een mini-game opent.
//
// function injectGamesButton() {
//   if (document.getElementById('smsc-games-btn')) return;
//   const btn = document.createElement('button');
//   btn.id = 'smsc-games-btn';
//   btn.textContent = '🎮';
//   btn.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;...';
//   btn.addEventListener('click', () => { /* open game overlay */ });
//   document.body.appendChild(btn);
// }
// injectGamesButton();
// ─────────────────────────────────────────────────────────────────────────────
