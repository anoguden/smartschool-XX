/**
 * popup.js — Smartschool Thema-Aanpasser
 * Beheert de popup-interface: thema-selectie, afbeelding-upload,
 * kleuranalyse en opslag via chrome.storage.local.
 *
 * Structuur:
 *  1. Constanten & helpers
 *  2. Initialisatie (laad opgeslagen instellingen)
 *  3. Thema-selectie
 *  4. Afbeelding-upload & kleuranalyse
 *  5. Reset
 *  6. Stuur bericht naar content.js
 *  7. TODO: GAMES-SECTIE
 */

// ── 1. Constanten & DOM-referenties ──────────────────────────────────────────

const themeCards   = document.querySelectorAll('.theme-card');
const uploadArea   = document.getElementById('uploadArea');
const fileInput    = document.getElementById('fileInput');
const uploadPreview = document.getElementById('uploadPreview');
const previewImg   = document.getElementById('previewImg');
const removeUpload = document.getElementById('removeUpload');
const overlayToggle = document.getElementById('overlayToggle');
const resetBtn     = document.getElementById('resetBtn');
const statusMsg    = document.getElementById('statusMsg');

/** Huidig thema-object dat wordt opgeslagen & doorgestuurd. */
let currentSettings = {
  theme: null,          // 'dark' | 'ocean' | 'sunset' | null
  customBg: null,       // base64 data-URL of null
  overlayColor: null,   // 'rgba(...)' berekend uit afbeelding
  useOverlay: true,     // auto-overlay ingeschakeld?
};

// ── 2. Initialisatie ──────────────────────────────────────────────────────────

chrome.storage.local.get('smscSettings', ({ smscSettings }) => {
  if (!smscSettings) return;
  currentSettings = { ...currentSettings, ...smscSettings };

  // Herstel thema-selectie
  if (currentSettings.theme) {
    markActiveTheme(currentSettings.theme);
  }

  // Herstel upload-voorvertoning
  if (currentSettings.customBg) {
    showPreview(currentSettings.customBg);
  }

  // Herstel overlay-toggle
  overlayToggle.checked = currentSettings.useOverlay ?? true;
});

// ── 3. Thema-selectie ─────────────────────────────────────────────────────────

themeCards.forEach(card => {
  card.addEventListener('click', () => {
    const chosen = card.dataset.theme;
    currentSettings.theme = chosen;
    // Eigen achtergrond wordt genegeerd als een thema actief is
    currentSettings.customBg = null;
    currentSettings.overlayColor = null;

    markActiveTheme(chosen);
    hidePreview();
    saveAndApply();
    showStatus('Thema opgeslagen ✓');
  });
});

/** Markeert de juiste kaart als actief. */
function markActiveTheme(theme) {
  themeCards.forEach(c => c.classList.toggle('active', c.dataset.theme === theme));
}

// ── 4. Afbeelding-upload & kleuranalyse ─────────────────────────────────────

uploadArea.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (!file) return;

  // Max 5 MB controle
  if (file.size > 5 * 1024 * 1024) {
    showStatus('Bestand is te groot (max 5 MB) ✗', true);
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    const dataUrl = e.target.result;

    // Deactiveer vooraf ingesteld thema
    currentSettings.theme = null;
    markActiveTheme(null);

    currentSettings.customBg = dataUrl;
    showPreview(dataUrl);

    if (currentSettings.useOverlay) {
      extractDominantColor(dataUrl, (color) => {
        currentSettings.overlayColor = color;
        saveAndApply();
      });
    } else {
      currentSettings.overlayColor = null;
      saveAndApply();
    }

    showStatus('Achtergrond opgeslagen ✓');
  };
  reader.readAsDataURL(file);
});

/** Toont de thumbnail-voorvertoning. */
function showPreview(dataUrl) {
  previewImg.src = dataUrl;
  uploadPreview.style.display = 'block';
}

/** Verbergt de thumbnail-voorvertoning. */
function hidePreview() {
  previewImg.src = '';
  uploadPreview.style.display = 'none';
  fileInput.value = '';
}

/** Verwijder-knop op de thumbnail. */
removeUpload.addEventListener('click', () => {
  currentSettings.customBg = null;
  currentSettings.overlayColor = null;
  hidePreview();
  saveAndApply();
  showStatus('Achtergrond verwijderd ✓');
});

/** Overlay-toggle. */
overlayToggle.addEventListener('change', () => {
  currentSettings.useOverlay = overlayToggle.checked;
  if (!currentSettings.useOverlay) {
    currentSettings.overlayColor = null;
  } else if (currentSettings.customBg) {
    extractDominantColor(currentSettings.customBg, (color) => {
      currentSettings.overlayColor = color;
      saveAndApply();
    });
    return; // saveAndApply wordt vanuit callback aangeroepen
  }
  saveAndApply();
});

/**
 * Analyseert de dominante kleur van een afbeelding via een <canvas>.
 * Samplet een raster van pixels en berekent het gemiddelde.
 *
 * @param {string} dataUrl - base64 afbeelding
 * @param {function} callback - ontvangt 'rgba(r, g, b, 0.45)'
 */
function extractDominantColor(dataUrl, callback) {
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    // Kleine resolutie voor snelheid
    canvas.width = 50;
    canvas.height = 50;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, 50, 50);

    const data = ctx.getImageData(0, 0, 50, 50).data;
    let r = 0, g = 0, b = 0, count = 0;

    // Sample elke 4e pixel voor snelheid
    for (let i = 0; i < data.length; i += 16) {
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
      count++;
    }

    r = Math.round(r / count);
    g = Math.round(g / count);
    b = Math.round(b / count);

    // Pas luminantie aan: donkere gemiddelden → iets ophelderen voor de overlay
    const overlay = `rgba(${r}, ${g}, ${b}, 0.45)`;
    callback(overlay);
  };
  img.src = dataUrl;
}

// ── 5. Reset ─────────────────────────────────────────────────────────────────

resetBtn.addEventListener('click', () => {
  currentSettings = { theme: null, customBg: null, overlayColor: null, useOverlay: true };
  markActiveTheme(null);
  hidePreview();
  overlayToggle.checked = true;
  saveAndApply();
  showStatus('Alle aanpassingen verwijderd ✓');
});

// ── 6. Opslaan & doorsturen naar content.js ───────────────────────────────────

/** Slaat instellingen op en stuurt ze naar het actieve tabblad. */
function saveAndApply() {
  chrome.storage.local.set({ smscSettings: currentSettings });

  // Stuur bericht naar content.js op het actieve Smartschool-tabblad
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.tabs.sendMessage(tabs[0].id, {
      type: 'APPLY_THEME',
      settings: currentSettings,
    }).catch(() => {
      // Tabblad is nog niet geladen of is geen Smartschool-pagina — stil negeren
    });
  });
}

/** Toont een korte statusmelding. */
function showStatus(msg, isError = false) {
  statusMsg.textContent = msg;
  statusMsg.style.color = isError ? '#ff6b6b' : '#3ecfcf';
  statusMsg.classList.add('visible');
  setTimeout(() => statusMsg.classList.remove('visible'), 2500);
}

// ─────────────────────────────────────────────────────────────────────────────
// TODO: GAMES-SECTIE
// Voeg hier de logica toe voor het games-gedeelte.
// Voorbeeld:
//
// const gamesBtn = document.getElementById('openGameBtn');
// gamesBtn?.addEventListener('click', () => {
//   chrome.tabs.create({ url: chrome.runtime.getURL('games/index.html') });
// });
//
// Of stuur een bericht naar content.js:
// chrome.tabs.sendMessage(tabId, { type: 'OPEN_GAME', game: 'snake' });
// ─────────────────────────────────────────────────────────────────────────────
